// @Author: Yu Xin

#include "input_reader.h"

#include <string>

// int Test1() {
    
// }

// int main() {
// 	std::string file_location = "./test.txt";
// 	InputReader input_reader;
// 	input_reader.ReadInputFile(file_location);
// }
